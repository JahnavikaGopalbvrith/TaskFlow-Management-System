import React, { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';
import DeleteModal from '../components/DeleteModal';
import Pagination from '../components/Pagination';
import Layout from '../components/Layout';
import { useAuth } from '../context/AuthContext';

const LIMIT = 8;

export default function Tasks() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, total: 0, totalPages: 1, limit: LIMIT });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [priority, setPriority] = useState('All');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [page, setPage] = useState(1);

  const [showCreate, setShowCreate] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [deleteTask, setDeleteTask] = useState(null);

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: LIMIT, sortBy, sortOrder };
      if (status !== 'All') params.status = status;
      if (priority !== 'All') params.priority = priority;
      if (search.trim()) params.search = search.trim();

      const { data } = await api.get('/tasks', { params });
      setTasks(data.data);
      setPagination(data.pagination);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to load tasks');
    } finally {
      setLoading(false);
    }
  }, [page, status, priority, search, sortBy, sortOrder]);

  useEffect(() => {
    const t = setTimeout(fetchTasks, search ? 400 : 0);
    return () => clearTimeout(t);
  }, [fetchTasks, search]);

  useEffect(() => { setPage(1); }, [status, priority, search, sortBy, sortOrder]);

  const handleCreate = async (form) => {
    setSaving(true);
    try {
      await api.post('/tasks', form);
      toast.success('Task created!');
      setShowCreate(false);
      fetchTasks();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create task');
    } finally { setSaving(false); }
  };

  const handleUpdate = async (form) => {
    setSaving(true);
    try {
      await api.put(`/tasks/${editTask._id}`, form);
      toast.success('Task updated!');
      setEditTask(null);
      fetchTasks();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update task');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    setSaving(true);
    try {
      await api.delete(`/tasks/${deleteTask._id}`);
      toast.success('Task deleted');
      setDeleteTask(null);
      fetchTasks();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete task');
    } finally { setSaving(false); }
  };

  const handleToggle = async (task) => {
    try {
      const { data } = await api.patch(`/tasks/${task._id}/toggle`);
      toast.success(data.message);
      setTasks(ts => ts.map(t => t._id === task._id ? data.data : t));
    } catch (err) {
      toast.error('Failed to update task');
    }
  };

  const greet = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <Layout>
      <div className="tasks-page">
        <div className="page-header">
          <div>
            <h1 className="page-title">{greet()}, {user?.name?.split(' ')[0]} ✦</h1>
            <p className="page-subtitle">
              {pagination.total === 0
                ? 'No tasks yet — start by creating one'
                : `${pagination.total} task${pagination.total !== 1 ? 's' : ''} in your workspace`}
            </p>
          </div>
          <button className="btn btn-primary" onClick={() => setShowCreate(true)}>+ New task</button>
        </div>

        <div className="filters-bar">
          <div className="search-wrap">
            <span className="search-icon">⌕</span>
            <input
              type="text"
              className="form-control search-input"
              placeholder="Search tasks..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          <select className="form-control filter-select" value={status} onChange={e => setStatus(e.target.value)}>
            <option value="All">All statuses</option>
            <option>Todo</option>
            <option>In Progress</option>
            <option>Done</option>
          </select>

          <select className="form-control filter-select" value={priority} onChange={e => setPriority(e.target.value)}>
            <option value="All">All priorities</option>
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
          </select>

          <select className="form-control filter-select" value={`${sortBy}_${sortOrder}`} onChange={e => {
            const [sb, so] = e.target.value.split('_');
            setSortBy(sb); setSortOrder(so);
          }}>
            <option value="createdAt_desc">Newest first</option>
            <option value="createdAt_asc">Oldest first</option>
            <option value="dueDate_asc">Due date ↑</option>
            <option value="dueDate_desc">Due date ↓</option>
            <option value="priority_asc">Priority ↑</option>
            <option value="priority_desc">Priority ↓</option>
          </select>
        </div>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
            <span className="spinner" style={{ width: 32, height: 32, borderWidth: 3 }} />
          </div>
        ) : tasks.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">◻</div>
            <div className="empty-state-title">
              {search || status !== 'All' || priority !== 'All' ? 'No tasks match your filters' : 'No tasks yet'}
            </div>
            <p style={{ fontSize: 14, marginTop: 6 }}>
              {search || status !== 'All' || priority !== 'All'
                ? 'Try adjusting your filters'
                : 'Create your first task to get started'}
            </p>
            {(!search && status === 'All' && priority === 'All') && (
              <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => setShowCreate(true)}>
                + Create task
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="task-list">
              {tasks.map(task => (
                <TaskCard
                  key={task._id}
                  task={task}
                  onEdit={setEditTask}
                  onDelete={setDeleteTask}
                  onToggle={handleToggle}
                />
              ))}
            </div>
            <Pagination pagination={{ ...pagination, page }} onPageChange={setPage} />
          </>
        )}
      </div>

      {showCreate && <TaskModal onSave={handleCreate} onClose={() => setShowCreate(false)} loading={saving} />}
      {editTask && <TaskModal task={editTask} onSave={handleUpdate} onClose={() => setEditTask(null)} loading={saving} />}
      {deleteTask && <DeleteModal task={deleteTask} onConfirm={handleDelete} onClose={() => setDeleteTask(null)} loading={saving} />}
    </Layout>
  );
}
