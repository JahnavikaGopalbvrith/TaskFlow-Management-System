import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

export default function Signup() {
  const { signup, loading } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name || form.name.length < 2) e.name = 'Name must be at least 2 characters';
    if (!form.email) e.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Enter a valid email';
    if (!form.password || form.password.length < 6) e.password = 'Password must be at least 6 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    const res = await signup(form.name, form.email, form.password);
    if (res.success) {
      toast.success('Account created! Welcome aboard 🎉');
      navigate('/');
    } else {
      toast.error(res.message);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-panel-left">
        <div className="auth-left-logo">TaskFlow<span style={{color:'#e85d26'}}>.</span></div>
        <div className="auth-left-content">
          <div className="auth-left-badge">✦ Start for free, no credit card needed</div>
          <h1 className="auth-left-headline">Your tasks,<br/>your rules,<br/>your flow.</h1>
          <p className="auth-left-sub">Join thousands who use TaskFlow to stay on top of their work and life.</p>
        </div>
        <div style={{color:'rgba(255,255,255,0.3)', fontSize:'12px'}}>© 2024 TaskFlow. All rights reserved.</div>
      </div>
      <div className="auth-panel-right">
        <div className="auth-form-box">
          <h2 className="auth-form-title">Create account</h2>
          <p className="auth-form-sub">Get started in seconds — it's completely free</p>
          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Full name</label>
              <input className="form-control" placeholder="Alex Johnson" value={form.name}
                onChange={e => setForm(f => ({...f, name: e.target.value}))}
                style={errors.name ? {borderColor:'var(--red)'} : {}} />
              {errors.name && <span style={{fontSize:'12px',color:'var(--red)'}}>{errors.name}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input className="form-control" type="email" placeholder="you@example.com" value={form.email}
                onChange={e => setForm(f => ({...f, email: e.target.value}))}
                style={errors.email ? {borderColor:'var(--red)'} : {}} />
              {errors.email && <span style={{fontSize:'12px',color:'var(--red)'}}>{errors.email}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input className="form-control" type="password" placeholder="Min. 6 characters" value={form.password}
                onChange={e => setForm(f => ({...f, password: e.target.value}))}
                style={errors.password ? {borderColor:'var(--red)'} : {}} />
              {errors.password && <span style={{fontSize:'12px',color:'var(--red)'}}>{errors.password}</span>}
            </div>
            <button className="btn btn-primary w-full" type="submit" disabled={loading} style={{justifyContent:'center',marginTop:'4px'}}>
              {loading ? <><span className="spinner" style={{width:16,height:16}}></span> Creating account…</> : 'Create account'}
            </button>
          </form>
          <p className="auth-link">Already have an account? <Link to="/login">Sign in</Link></p>
        </div>
      </div>
    </div>
  );
}
