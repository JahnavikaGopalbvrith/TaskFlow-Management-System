import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import Layout from '../components/Layout';
import api from '../utils/api';
import toast from 'react-hot-toast';

const STATUS_COLORS = { Todo: '#60a5fa', 'In Progress': '#f07040', Done: '#52b788' };
const PRIORITY_COLORS = { Low: '#9e9892', Medium: '#fbbf24', High: '#f87171' };

function StatCard({ label, value, type, icon }) {
  return (
    <div className={`stat-card ${type}`}>
      <div className="stat-icon">{icon}</div>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

function CompletionRing({ percentage }) {
  const r = 70;
  const circ = 2 * Math.PI * r;
  const stroke = circ - (percentage / 100) * circ;
  return (
    <div className="completion-ring">
      <svg width="180" height="180" viewBox="0 0 180 180">
        <circle cx="90" cy="90" r={r} fill="none" stroke="var(--bg-3)" strokeWidth="14" />
        <circle cx="90" cy="90" r={r} fill="none" stroke="var(--accent-2)"
          strokeWidth="14" strokeDasharray={circ} strokeDashoffset={stroke}
          strokeLinecap="round" transform="rotate(-90 90 90)"
          style={{transition:'stroke-dashoffset 1s ease'}} />
        <text x="90" y="85" textAnchor="middle" style={{fontFamily:'Syne,sans-serif', fontSize:'32px', fontWeight:'800', fill:'var(--text)'}}>
          {percentage}%
        </text>
        <text x="90" y="108" textAnchor="middle" style={{fontSize:'12px', fill:'var(--text-2)'}}>
          complete
        </text>
      </svg>
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div style={{background:'var(--bg-2)', border:'1px solid var(--border)', borderRadius:'8px', padding:'10px 14px', fontSize:'13px', color:'var(--text)'}}>
        <div style={{fontWeight:600}}>{label}</div>
        <div>{payload[0].value} tasks</div>
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/analytics')
      .then(res => setData(res.data.data))
      .catch(() => toast.error('Failed to load analytics'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <Layout>
      <div className="loading-screen"><span className="spinner" style={{width:32,height:32}}></span></div>
    </Layout>
  );

  if (!data) return <Layout><div className="empty-state"><p>No analytics data available.</p></div></Layout>;

  const { overview, byStatus, byPriority, recentTasks, completionByDay } = data;

  const statusChartData = Object.entries(byStatus).map(([name, value]) => ({ name, value }));
  const priorityChartData = Object.entries(byPriority).map(([name, value]) => ({ name, value }));

  const dayChartData = completionByDay.map(d => ({
    name: d._id.slice(5), // MM-DD
    tasks: d.count
  }));

  return (
    <Layout>
      <div className="analytics-page">
        <div className="page-header" style={{padding:'32px 0 0'}}>
          <div>
            <h1 className="page-title">Analytics</h1>
            <p className="page-subtitle">Your productivity at a glance</p>
          </div>
        </div>

        {/* Stat Cards */}
        <div className="stats-grid">
          <StatCard label="Total Tasks" value={overview.total} type="total" icon="☑" />
          <StatCard label="Completed" value={overview.completed} type="completed" icon="✓" />
          <StatCard label="Pending" value={overview.pending} type="pending" icon="◷" />
          <StatCard label="In Progress" value={overview.inProgress} type="inprogress" icon="⟳" />
          <StatCard label="Overdue" value={overview.overdue} type="overdue" icon="⚠" />
        </div>

        {/* Charts Row */}
        <div className="charts-grid">
          {/* Completion Ring */}
          <div className="chart-card">
            <div className="chart-title">Completion Rate</div>
            <CompletionRing percentage={overview.completionPercentage} />
            <div style={{textAlign:'center', marginTop:'8px', fontSize:'13px', color:'var(--text-2)'}}>
              {overview.completed} of {overview.total} tasks done
            </div>
          </div>

          {/* Status Breakdown */}
          <div className="chart-card">
            <div className="chart-title">Tasks by Status</div>
            <div className="progress-bar-wrap">
              {statusChartData.map(({ name, value }) => (
                <div key={name} className="progress-row">
                  <span className="progress-label">{name}</span>
                  <div className="progress-track">
                    <div className="progress-fill"
                      style={{width: overview.total ? `${(value/overview.total)*100}%` : '0%',
                        background: STATUS_COLORS[name]}} />
                  </div>
                  <span className="progress-count">{value}</span>
                </div>
              ))}
            </div>
            <div style={{marginTop:'16px'}}>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={statusChartData} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                    dataKey="value" paddingAngle={3}>
                    {statusChartData.map(({ name }) => (
                      <Cell key={name} fill={STATUS_COLORS[name]} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend formatter={(value) => <span style={{fontSize:'12px', color:'var(--text-2)'}}>{value}</span>} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Priority Breakdown */}
          <div className="chart-card">
            <div className="chart-title">Tasks by Priority</div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={priorityChartData} margin={{top:10, right:10, left:-10, bottom:0}}>
                <XAxis dataKey="name" tick={{fontSize:12, fill:'var(--text-2)'}} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} tick={{fontSize:12, fill:'var(--text-2)'}} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} cursor={{fill:'var(--bg-3)'}} />
                <Bar dataKey="value" radius={[6,6,0,0]}>
                  {priorityChartData.map(({ name }) => (
                    <Cell key={name} fill={PRIORITY_COLORS[name]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Completed last 7 days */}
          <div className="chart-card">
            <div className="chart-title">Completed — Last 7 Days</div>
            {dayChartData.length === 0 ? (
              <div className="empty-state" style={{padding:'40px 0'}}>
                <div style={{fontSize:'32px'}}>📈</div>
                <p style={{marginTop:'8px'}}>No completions yet this week</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={dayChartData} margin={{top:10, right:10, left:-10, bottom:0}}>
                  <XAxis dataKey="name" tick={{fontSize:12, fill:'var(--text-2)'}} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{fontSize:12, fill:'var(--text-2)'}} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} cursor={{fill:'var(--bg-3)'}} />
                  <Bar dataKey="tasks" fill="var(--accent-2)" radius={[6,6,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Recent Tasks */}
        {recentTasks.length > 0 && (
          <div className="chart-card" style={{marginTop:'20px'}}>
            <div className="chart-title">Recently Added</div>
            <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
              {recentTasks.map(task => (
                <div key={task._id} style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 0', borderBottom:'1px solid var(--border)'}}>
                  <div style={{flex:1, fontWeight:'500', fontSize:'14px', fontFamily:'Syne,sans-serif'}}>{task.title}</div>
                  <span className={`badge badge-${task.status.toLowerCase().replace(' ','')}`}>{task.status}</span>
                  <span className={`badge badge-${task.priority.toLowerCase()}`}>{task.priority}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
