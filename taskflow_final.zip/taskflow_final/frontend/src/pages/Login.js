import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login, loading } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.email) e.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Enter a valid email';
    if (!form.password) e.password = 'Password is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    const res = await login(form.email, form.password);
    if (res.success) {
      toast.success('Welcome back!');
      navigate('/');
    } else {
      toast.error(res.message);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-panel-left">
        <div className="auth-left-logo">TaskFlow<span style={{color:'#e85d26'}}>.</span></div>
        <div className="auth-left-content">
          <div className="auth-left-badge">✦ Organized. Focused. Done.</div>
          <h1 className="auth-left-headline">Manage tasks<br/>without the<br/>chaos.</h1>
          <p className="auth-left-sub">A clean, focused workspace to track what matters — with analytics to show your progress.</p>
        </div>
        <div style={{color:'rgba(255,255,255,0.3)', fontSize:'12px'}}>© 2024 TaskFlow. All rights reserved.</div>
      </div>
      <div className="auth-panel-right">
        <div className="auth-form-box">
          <h2 className="auth-form-title">Welcome back</h2>
          <p className="auth-form-sub">Sign in to your account to continue</p>
          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input
                className={`form-control ${errors.email ? 'error' : ''}`}
                type="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                style={errors.email ? {borderColor:'var(--red)'} : {}}
              />
              {errors.email && <span style={{fontSize:'12px',color:'var(--red)'}}>{errors.email}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-control"
                type="password"
                placeholder="••••••••"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                style={errors.password ? {borderColor:'var(--red)'} : {}}
              />
              {errors.password && <span style={{fontSize:'12px',color:'var(--red)'}}>{errors.password}</span>}
            </div>
            <button className="btn btn-primary w-full" type="submit" disabled={loading} style={{justifyContent:'center',marginTop:'4px'}}>
              {loading ? <><span className="spinner" style={{width:16,height:16}}></span> Signing in…</> : 'Sign in'}
            </button>
          </form>
          <p className="auth-link">
            Don't have an account? <Link to="/signup">Create one</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
