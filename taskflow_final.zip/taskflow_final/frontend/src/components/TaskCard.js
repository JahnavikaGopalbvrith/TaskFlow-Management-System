import React from 'react';
import { format, isPast, isWithinInterval, addDays } from 'date-fns';

const statusClass = { 'Todo': 'todo', 'In Progress': 'inprogress', 'Done': 'done' };
const priorityClass = { 'Low': 'low', 'Medium': 'medium', 'High': 'high' };

export default function TaskCard({ task, onToggle, onEdit, onDelete }) {
  const isDone = task.status === 'Done';

  const getDueDateInfo = () => {
    if (!task.dueDate) return null;
    const due = new Date(task.dueDate);
    const now = new Date();
    const isOverdue = !isDone && isPast(due);
    const isSoon = !isDone && !isOverdue && isWithinInterval(due, { start: now, end: addDays(now, 3) });
    return { label: format(due, 'MMM d'), isOverdue, isSoon };
  };

  const dueDateInfo = getDueDateInfo();

  return (
    <div className={`task-card ${isDone ? 'done' : ''}`}>
      <button className={`task-check ${isDone ? 'checked' : ''}`} onClick={() => onToggle(task._id)} title="Toggle complete">
        {isDone && <span style={{fontSize:'11px', fontWeight:'700'}}>✓</span>}
      </button>

      <div className="task-body">
        <div className={`task-title ${isDone ? 'strikethrough' : ''}`}>{task.title}</div>
        {task.description && <div className="task-desc">{task.description}</div>}
        <div className="task-meta">
          <span className={`badge badge-${statusClass[task.status]}`}>{task.status}</span>
          <span className={`badge badge-${priorityClass[task.priority]}`}>{task.priority}</span>
          {dueDateInfo && (
            <span className={`due-date ${dueDateInfo.isOverdue ? 'overdue' : dueDateInfo.isSoon ? 'soon' : ''}`}>
              {dueDateInfo.isOverdue ? '⚠ ' : '⏰ '}{dueDateInfo.label}
            </span>
          )}
        </div>
      </div>

      <div className="task-actions">
        <button className="btn-icon" onClick={() => onEdit(task)} title="Edit">✎</button>
        <button className="btn-icon" onClick={() => onDelete(task._id)}
          title="Delete" style={{color:'var(--red)', borderColor:'var(--red-soft)'}}>✕</button>
      </div>
    </div>
  );
}
