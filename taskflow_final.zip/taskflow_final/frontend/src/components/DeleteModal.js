import React from 'react';

export default function DeleteModal({ task, onConfirm, onClose, loading }) {
  if (!task) return null;
  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 380 }}>
        <div className="modal-header">
          <h3 className="modal-title">Delete task</h3>
          <button className="btn-icon" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <p style={{ color: 'var(--text-2)', fontSize: 14 }}>
            Are you sure you want to delete{' '}
            <strong style={{ color: 'var(--text)' }}>"{task.title}"</strong>?
            This action cannot be undone.
          </p>
        </div>
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose} disabled={loading}>Cancel</button>
          <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
            {loading
              ? <span className="spinner" style={{ borderTopColor: 'var(--red)', width: 14, height: 14, borderWidth: 2 }} />
              : null}
            Delete task
          </button>
        </div>
      </div>
    </div>
  );
}
