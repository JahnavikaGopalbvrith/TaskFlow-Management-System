const { getTaskAnalytics } = require('../services/analyticsService');

// @route   GET /api/analytics
const getAnalytics = async (req, res, next) => {
  try {
    const data = await getTaskAnalytics(req.user._id);
    res.json({ success: true, data });
  } catch (err) { next(err); }
};

module.exports = { getAnalytics };
