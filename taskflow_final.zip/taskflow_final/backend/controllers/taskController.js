const taskService = require('../services/taskService');

// @route   GET /api/tasks
const getTasks = async (req, res, next) => {
  try {
    const { status, priority, search, page, limit, sortBy, sortOrder } = req.query;
    const result = await taskService.getAllTasks({
      userId: req.user._id, status, priority, search, page, limit, sortBy, sortOrder
    });
    res.json({ success: true, data: result.tasks, pagination: result.pagination });
  } catch (err) { next(err); }
};

// @route   GET /api/tasks/:id
const getTask = async (req, res, next) => {
  try {
    const task = await taskService.getTaskById(req.params.id, req.user._id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    res.json({ success: true, data: task });
  } catch (err) { next(err); }
};

// @route   POST /api/tasks
const createTask = async (req, res, next) => {
  try {
    const { title, description, status, priority, dueDate, tags } = req.body;
    const task = await taskService.createTask({ title, description, status, priority, dueDate, tags, userId: req.user._id });
    res.status(201).json({ success: true, message: 'Task created!', data: task });
  } catch (err) { next(err); }
};

// @route   PUT /api/tasks/:id
const updateTask = async (req, res, next) => {
  try {
    const task = await taskService.updateTask(req.params.id, req.user._id, req.body);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    res.json({ success: true, message: 'Task updated!', data: task });
  } catch (err) { next(err); }
};

// @route   DELETE /api/tasks/:id
const deleteTask = async (req, res, next) => {
  try {
    const task = await taskService.deleteTask(req.params.id, req.user._id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    res.json({ success: true, message: 'Task deleted successfully.' });
  } catch (err) { next(err); }
};

// @route   PATCH /api/tasks/:id/toggle
const toggleTask = async (req, res, next) => {
  try {
    const task = await taskService.toggleTaskStatus(req.params.id, req.user._id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    res.json({ success: true, message: `Task marked as ${task.status}!`, data: task });
  } catch (err) { next(err); }
};

module.exports = { getTasks, getTask, createTask, updateTask, deleteTask, toggleTask };
