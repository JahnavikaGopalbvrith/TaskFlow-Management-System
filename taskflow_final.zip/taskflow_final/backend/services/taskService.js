const Task = require('../models/Task');

/**
 * All DB logic lives here.
 * Controllers stay thin — they just call services and send responses.
 */

const getAllTasks = async ({ userId, status, priority, search, page, limit, sortBy, sortOrder }) => {
  const query = { user: userId };

  if (status && status !== 'All') query.status = status;
  if (priority && priority !== 'All') query.priority = priority;
  if (search) {
    query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
  }

  const pageNum = Math.max(1, parseInt(page) || 1);
  const limitNum = Math.min(50, Math.max(1, parseInt(limit) || 10));
  const skip = (pageNum - 1) * limitNum;

  const allowedSortFields = ['createdAt', 'updatedAt', 'dueDate', 'title', 'status'];
  const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'createdAt';
  const sortDir = sortOrder === 'asc' ? 1 : -1;

  // Priority needs custom ordering (High > Medium > Low)
  if (sortBy === 'priority') {
    const tasks = await Task.find(query).lean();
    const order = { High: 0, Medium: 1, Low: 2 };
    const sorted = tasks.sort((a, b) => {
      const diff = (order[a.priority] ?? 1) - (order[b.priority] ?? 1);
      return sortDir === 1 ? diff : -diff;
    });
    const total = sorted.length;
    return {
      tasks: sorted.slice(skip, skip + limitNum),
      pagination: { total, page: pageNum, limit: limitNum, totalPages: Math.ceil(total / limitNum) }
    };
  }

  const sortOptions = { [sortField]: sortDir };
  const [tasks, total] = await Promise.all([
    Task.find(query).sort(sortOptions).skip(skip).limit(limitNum).lean(),
    Task.countDocuments(query)
  ]);

  return {
    tasks,
    pagination: { total, page: pageNum, limit: limitNum, totalPages: Math.ceil(total / limitNum) }
  };
};

const getTaskById = async (taskId, userId) => {
  // Always filter by user — prevents accessing another user's task
  return Task.findOne({ _id: taskId, user: userId });
};

const createTask = async ({ title, description, status, priority, dueDate, tags, userId }) => {
  return Task.create({ title, description, status, priority, dueDate, tags, user: userId });
};

const updateTask = async (taskId, userId, updates) => {
  // findOne first to confirm ownership, then update
  const task = await Task.findOne({ _id: taskId, user: userId });
  if (!task) return null;

  const allowedFields = ['title', 'description', 'status', 'priority', 'dueDate', 'tags'];
  const safeUpdates = {};
  allowedFields.forEach(field => {
    if (updates[field] !== undefined) safeUpdates[field] = updates[field];
  });

  return Task.findByIdAndUpdate(taskId, safeUpdates, { new: true, runValidators: true });
};

const deleteTask = async (taskId, userId) => {
  return Task.findOneAndDelete({ _id: taskId, user: userId });
};

const toggleTaskStatus = async (taskId, userId) => {
  const task = await Task.findOne({ _id: taskId, user: userId });
  if (!task) return null;
  task.status = task.status === 'Done' ? 'Todo' : 'Done';
  await task.save();
  return task;
};

module.exports = { getAllTasks, getTaskById, createTask, updateTask, deleteTask, toggleTaskStatus };
