const mongoose = require('mongoose');
const Task = require('../models/Task');

const getTaskAnalytics = async (userId) => {
  const objectId = new mongoose.Types.ObjectId(userId);

  // Run all aggregations in parallel for performance
  const [statusStats, priorityStats, overdueCount, recentTasks, completionByDay] = await Promise.all([

    // Aggregation: tasks grouped by status
    Task.aggregate([
      { $match: { user: objectId } },
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]),

    // Aggregation: tasks grouped by priority
    Task.aggregate([
      { $match: { user: objectId } },
      { $group: { _id: '$priority', count: { $sum: 1 } } }
    ]),

    // Count overdue tasks (not done + past due date)
    Task.countDocuments({
      user: userId,
      status: { $ne: 'Done' },
      dueDate: { $lt: new Date(), $ne: null }
    }),

    // 5 most recently created tasks
    Task.find({ user: userId })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('title status priority createdAt dueDate')
      .lean(),

    // Completed tasks per day — last 7 days
    Task.aggregate([
      {
        $match: {
          user: objectId,
          status: 'Done',
          completedAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
        }
      },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$completedAt' } },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ])
  ]);

  // Build status map
  const statusMap = { Todo: 0, 'In Progress': 0, Done: 0 };
  statusStats.forEach(s => { statusMap[s._id] = s.count; });

  const total = Object.values(statusMap).reduce((a, b) => a + b, 0);
  const completed = statusMap['Done'];
  const pending = statusMap['Todo'] + statusMap['In Progress'];
  const completionPercentage = total > 0 ? Math.round((completed / total) * 100) : 0;

  // Build priority map
  const priorityMap = { Low: 0, Medium: 0, High: 0 };
  priorityStats.forEach(p => { priorityMap[p._id] = p.count; });

  return {
    overview: { total, completed, pending, inProgress: statusMap['In Progress'], overdue: overdueCount, completionPercentage },
    byStatus: statusMap,
    byPriority: priorityMap,
    recentTasks,
    completionByDay
  };
};

module.exports = { getTaskAnalytics };
