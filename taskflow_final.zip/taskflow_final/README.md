# TaskFlow — Full Stack Task Management System (Production Grade)

A production-ready task management app built with React, Node.js/Express, and MongoDB.

## ✅ Security & Architecture Improvements (v2.0)

| Feature | Details |
|---|---|
| `helmet` | Sets 14 secure HTTP headers automatically |
| `express-rate-limit` | 100 req/15min globally, 20 req/15min on auth routes |
| `express-mongo-sanitize` | Blocks NoSQL injection attacks (`{ $gt: '' }`) |
| `xss-clean` | Sanitizes HTML/JS from all request body fields |
| Body size limit | `express.json({ limit: '10kb' })` prevents payload attacks |
| JWT hardened | No fallback secret — throws if `JWT_SECRET` not in `.env` |
| Services layer | Business logic in `services/` — controllers stay thin |
| ObjectId fix | Analytics aggregations use `mongoose.Types.ObjectId` correctly |
| Error handler | Stack traces hidden in production |

## Features

- **Authentication** — JWT signup/login, bcrypt (salt 12), token auto-expiry handling
- **Task CRUD** — Create, read, update, delete with full ownership checks
- **Authorization** — Every task query uses `{ _id, user }` — no cross-user access possible
- **Filtering & Search** — Status, priority, debounced title/description search
- **Sorting** — Newest, oldest, due date, priority (custom order: High > Medium > Low)
- **Pagination** — Server-side, 8 per page
- **Analytics** — Aggregation-based stats, pie chart, bar chart, progress bars
- **Dark Mode** — Full CSS variable system, persisted to localStorage
- **Responsive** — Mobile drawer sidebar, stacked filters, fluid grid
- **Global Error Handling** — Consistent `{ success, message }` responses everywhere
- **MongoDB Indexes** — 5 compound indexes for optimized queries
- **Role-based Auth** — `authorize('admin')` middleware ready to use

## Project Structure

```
taskflow/
├── backend/
│   ├── controllers/       ← Thin: receive request, call service, send response
│   │   ├── authController.js
│   │   ├── taskController.js
│   │   └── analyticsController.js
│   ├── services/          ← All business logic lives here
│   │   ├── taskService.js
│   │   └── analyticsService.js
│   ├── middleware/
│   │   ├── auth.js        ← JWT protect + RBAC authorize
│   │   ├── errorHandler.js← Global error handler
│   │   └── validate.js    ← express-validator rules
│   ├── models/
│   │   ├── User.js        ← bcrypt hooks, password hidden from JSON
│   │   └── Task.js        ← 5 indexes, completedAt auto-set
│   ├── routes/
│   │   ├── auth.js        ← Rate limited separately
│   │   ├── tasks.js
│   │   └── analytics.js
│   ├── server.js          ← helmet, rate limit, sanitize, xss
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Layout.js
│   │   │   ├── Sidebar.js
│   │   │   ├── TaskCard.js
│   │   │   ├── TaskModal.js
│   │   │   ├── DeleteModal.js   ← Confirmation before delete
│   │   │   ├── Pagination.js
│   │   │   └── ProtectedRoute.js
│   │   ├── context/
│   │   │   ├── AuthContext.js   ← Auto-logout on 401
│   │   │   └── ThemeContext.js
│   │   ├── pages/
│   │   │   ├── Login.js
│   │   │   ├── Signup.js
│   │   │   ├── Tasks.js         ← Full CRUD + filters + pagination
│   │   │   └── Analytics.js     ← Charts + stats
│   │   ├── utils/api.js         ← Axios instance + interceptors
│   │   └── styles/global.css    ← CSS variables, dark mode
│   └── package.json
│
└── docker-compose.yml
```

## Quick Start (Local Dev)

### Prerequisites
- Node.js 18+
- MongoDB running locally OR MongoDB Atlas URI

### Backend
```bash
cd taskflow/backend
cp .env.example .env
# Edit .env — set your MONGODB_URI and a strong JWT_SECRET
npm install
npm run dev
# → http://localhost:5000
```

### Frontend (new terminal)
```bash
cd taskflow/frontend
npm install
npm start
# → http://localhost:3000
```

## Quick Start (Docker)

```bash
docker-compose up -d
# App:  http://localhost:3000
# API:  http://localhost:5000
```

## API Reference

### Auth (rate limited: 20 req/15min)
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/auth/signup | ✗ | Register |
| POST | /api/auth/login | ✗ | Login |
| GET | /api/auth/me | ✓ | Current user |

### Tasks
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/tasks | List (filter, search, sort, paginate) |
| POST | /api/tasks | Create |
| GET | /api/tasks/:id | Get one |
| PUT | /api/tasks/:id | Update |
| DELETE | /api/tasks/:id | Delete |
| PATCH | /api/tasks/:id/toggle | Toggle Done/Todo |

### Analytics
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/analytics | Aggregated insights |

## Environment Variables

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/taskflow
JWT_SECRET=replace_with_long_random_string_min_32_chars
JWT_EXPIRE=7d
NODE_ENV=development
CLIENT_URL=http://localhost:3000
```

## MongoDB Indexes

```js
{ user: 1, status: 1 }          // Filter by status
{ user: 1, priority: 1 }        // Filter by priority
{ user: 1, dueDate: 1 }         // Sort by due date
{ user: 1, createdAt: -1 }      // Default sort
{ title: 'text', description: 'text' }  // Full-text search
```

## Interview Talking Points

- **Security**: helmet headers, rate limiting, NoSQL injection prevention, XSS sanitization, body size limit
- **Architecture**: MVC + Services pattern — controllers are thin, all logic in services
- **Authorization**: Every task query scoped to `req.user._id` — impossible to access another user's tasks
- **DB Optimization**: MongoDB aggregation pipelines for analytics, compound indexes for all common queries
- **Error Handling**: Global middleware catches all errors, consistent JSON format, no stack traces in production
- **Frontend**: Centralized Axios instance with request/response interceptors, auto-logout on 401
